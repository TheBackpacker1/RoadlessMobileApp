package com.example.scaffoldtp3.data

data class Massage(var user:String,var msg:String)



var msg1 = Massage("UNKNOWN","hello how are you");
var msg2 = Massage("UNKNOWN","hello how are you");
var msg3 = Massage("UNKNOWN","hello how are you hhhhh hhhh hhhhh hhhhhhh hhhhhhhh hh hhhh hhh hhh");
var msg4 = Massage("UNKNOWN","hello how are you");
var msg5 = Massage("UNKNOWN","hello how are you aa aaaaaaaa aaaaaa aaaaaa aaaaaaa a aaaaaaaaa aaaaaaaaaaaaaaaaa aaaaaaaaaaaa aaaaaaaaa");
val msglist = listOf(msg1, msg2, msg3, msg4, msg5)